import streamlit as st
import requests
import pandas as pd
import pydeck as pdk
from geopy.distance import geodesic
import numpy as np
from fpdf import FPDF
import io

st.set_page_config(page_title="Indian Property Insurance Underwriting Tool", layout="wide")
st.title("Indian Property Insurance Underwriting Risk Analysis Tool")

# --- Elevation API ---
def get_elevation(lat, lon):
    try:
        url = f"https://api.open-elevation.com/api/v1/lookup?locations={lat},{lon}"
        r = requests.get(url); r.raise_for_status()
        res = r.json().get('results')
        return res[0]['elevation'] if res else None
    except:
        return None

# --- Flood risk classification ---
def classify_flood_risk(elev):
    if elev is None: return "Unknown"
    return "High Flood Risk" if elev < 5 else "Medium Flood Risk" if elev < 15 else "Low Flood Risk"

# --- Indian urban flooding zones ---
flood_zones = [
    {"name": "Mumbai", "bounds": [(18.90, 72.75), (19.15, 72.95)]},
    {"name": "Chennai", "bounds": [(13.00, 80.20), (13.15, 80.30)]},
    {"name": "Kolkata", "bounds": [(22.45, 88.30), (22.60, 88.45)]},
    {"name": "Delhi", "bounds": [(28.55, 77.15), (28.75, 77.35)]},
    {"name": "Bengaluru", "bounds": [(12.90, 77.50), (13.05, 77.65)]},
]
def point_in_bounds(lat, lon, bounds):
    (lat_min, lon_min), (lat_max, lon_max) = bounds
    return lat_min <= lat <= lat_max and lon_min <= lon <= lon_max
def check_urban_flood_risk(lat, lon):
    for zone in flood_zones:
        if point_in_bounds(lat, lon, zone['bounds']):
            return f"High Urban Flood Risk ({zone['name']})"
    return "Low Urban Flood Risk"

# --- Fire stations ---
fire_stations = pd.DataFrame([
    {"name":"Mumbai FS1","lat":19.015,"lon":72.85},
    {"name":"Chennai FS1","lat":13.08,"lon":80.275},
    {"name":"Kolkata FS1","lat":22.57,"lon":88.36},
    {"name":"Delhi FS1","lat":28.65,"lon":77.20},
    {"name":"Bengaluru FS1","lat":12.98,"lon":77.58},
])
def estimate_response_time(lat, lon):
    best, min_t = None, None
    for _, fs in fire_stations.iterrows():
        d = geodesic((lat, lon), (fs.lat, fs.lon)).km
        t = d/40*60
        if min_t is None or t<min_t:
            best, min_t = fs['name'], t
    return best, round(min_t,1) if min_t else None

def generate_surrounding_exposure(lat, lon, n=5):
    np.random.seed(42)
    lats = lat + (np.random.rand(n)-0.5)/100
    lons = lon + (np.random.rand(n)-0.5)/100
    risks = np.random.choice(['Low','Medium','High'],n)
    return pd.DataFrame({'lat':lats,'lon':lons,'risk':risks})

def create_pdf_report(lat, lon, elev, flood_risk, urb, fs, rt, df):
    pdf = FPDF(); pdf.add_page(); pdf.set_font('Arial','B',16)
    pdf.cell(0,10,'Property Insurance Underwriting Risk Analysis Report',ln=True,align='C')
    pdf.ln(10); pdf.set_font('Arial','',12)
    pdf.cell(0,10,f'Coords: {lat:.6f},{lon:.6f}',ln=True)
    pdf.cell(0,10,f'Elevation: {elev if elev else "N/A"} m',ln=True)
    pdf.cell(0,10,f'Flood Risk: {flood_risk}',ln=True)
    pdf.cell(0,10,f'Urban Flood Risk: {urb}',ln=True)
    pdf.cell(0,10,f'Fire Station: {fs}',ln=True)
    pdf.cell(0,10,f'Response Time: {rt} min',ln=True)
    pdf.ln(10); pdf.cell(0,10,'Nearby Exposure:',ln=True)
    pdf.set_font('Arial','',10)
    pdf.cell(40,10,'Lat',1); pdf.cell(40,10,'Lon',1); pdf.cell(40,10,'Risk',1); pdf.ln()
    for _,r in df.iterrows():
        pdf.cell(40,10,f'{r.lat:.6f}',1); pdf.cell(40,10,f'{r.lon:.6f}',1); pdf.cell(40,10,r.risk,1); pdf.ln()
    bio=io.BytesIO(); pdf.output(bio); bio.seek(0); return bio

st.write("Select location in India")
viewport={'latitude':20.5937,'longitude':78.9629,'zoom':5}
if 'sel' not in st.session_state: st.session_state.sel=(viewport['latitude'],viewport['longitude'])
lat_sel, lon_sel = st.session_state.sel
# Map
layers=[]
for z in flood_zones:
    (minlat,minlon),(maxlat,maxlon)=z['bounds']
    poly=[[minlon,minlat],[maxlon,minlat],[maxlon,maxlat],[minlon,maxlat]]
    layers.append(pdk.Layer('PolygonLayer',data=[{'polygon':poly}],get_polygon='polygon',get_fill_color=[255,0,0,50]))
layers.append(pdk.Layer('ScatterplotLayer',data=fire_stations,get_position=['lon','lat'],get_fill_color=[255,0,0],get_radius=80))
layers.append(pdk.Layer('ScatterplotLayer',data=[{'lat':lat_sel,'lon':lon_sel}],get_position=['lon','lat'],get_color=[0,128,255],get_radius=150))
exp_df=generate_surrounding_exposure(lat_sel,lon_sel)
layers.append(pdk.Layer('ScatterplotLayer',data=exp_df,get_position=['lon','lat'],get_fill_color=[255,165,0],get_radius=70))
r=pdk.Deck(map_style='mapbox://styles/mapbox/streets-v11',initial_view_state=pdk.ViewState(**viewport),layers=layers)
st.pydeck_chart(r)

with st.expander("Enter coords"):
    lat_in=st.number_input("Latitude",value=lat_sel,format="%.6f",min_value=6.0,max_value=37.0)
    lon_in=st.number_input("Longitude",value=lon_sel,format="%.6f",min_value=68.0,max_value=97.5)
    if st.button("Update Location"):
        new=(lat_in,lon_in)
        if new!=st.session_state.sel:
            st.session_state.sel=new
            st.success(f"Updated to {new}")
# Analysis
lat_sel,lon_sel=st.session_state.sel
elev=get_elevation(lat_sel,lon_sel)
fr=classify_flood_risk(elev)
uf=check_urban_flood_risk(lat_sel,lon_sel)
fs,rt=estimate_response_time(lat_sel,lon_sel)
st.write(f"Elevation: {elev} m, Flood Risk: {fr}, Urban Flood: {uf}, Station: {fs}, ETA: {rt} min")
st.write("Exposure:")
st.dataframe(exp_df)
pdf=create_pdf_report(lat_sel,lon_sel,elev,fr,uf,fs,rt,exp_df)
st.download_button("Download PDF",data=pdf,file_name="report.pdf",mime="application/pdf")
