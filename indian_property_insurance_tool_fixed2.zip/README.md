# Indian Property Insurance Underwriting Tool

Streamlit app for property insurance risk analysis across India.

## Features
- Interactive map for location selection.
- Elevation & flood risk (Open-Elevation).
- Urban flood zones for major metros.
- Fire brigade response time estimation.
- Exposure simulation & PDF report.

## Setup
```
git clone https://github.com/yourusername/indian-property-insurance-tool.git
cd indian-property-insurance-tool
pip install -r requirements.txt
streamlit run app.py
```

## Deploy
- Push to GitHub.
- Use Streamlit Cloud: select repo, branch, `app.py`.
